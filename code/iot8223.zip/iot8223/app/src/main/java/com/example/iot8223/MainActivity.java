package com.example.iot8223;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import java.lang.String;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
/*import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.ServerAddress;
import com.mongodb.MongoCredential;
import com.mongodb.MongoClientOptions;*/
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import android.content.Context;
import android.widget.TextView;
import android.content.Intent;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.*;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnPausedListener;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    Button b1,b2;
    TextView tv1;
    String filename ="BackGround_service2.txt";
    Sensor a,g,m,p,r,v,l;
    // to handle mutiple sensors
    SensorManager sm;
    float avals[],gvals[],mvals[], pvals[], rvals[], vvals[],lvals[];//accelerometer , gyroscope, magnetic field values, pressure values, rotation, motion,proximity
    boolean flag = false;//sensors are working or not
    @RequiresApi(api = Build.VERSION_CODES.Q)
   // MongoClient mongoClient = new MongoClient();
    String taskValue;
    private static final String TAG = "MainActivity";

    @RequiresApi(api = Build.VERSION_CODES.Q)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = (Button)findViewById(R.id.b1);
        b2 = (Button)findViewById(R.id.b2);
        tv1 = findViewById(R.id.textView);

        ActivityManager activityManager = (ActivityManager)getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.AppTask> tasks = Objects.requireNonNull(activityManager).getAppTasks();
        Intent startServiceIntent = new Intent(MainActivity.this, MyBackgroundService.class);
        startService(startServiceIntent);

       /* for (ActivityManager.AppTask task : tasks) {
            taskValue = "Application executed : " + task.getTaskInfo().baseActivity.toShortString() + "\tID: " + task.getTaskInfo().taskId + "\n";
            tv1.setText(taskValue);
        }*///https://iotmobilesenordata-default-rtdb.firebaseio.com/
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://iotmobilesenordata-default-rtdb.firebaseio.com/");

        DatabaseReference myRef = database.getReference("STATUS");
        myRef.setValue("Start");
        // Read from the database
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String value = dataSnapshot.getValue(String.class);
                Log.d(TAG, "Value is: " + value);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });
        b1.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) { //button's logic

                tv1.setText("Background Service Started");
                Intent startServiceIntent = new Intent(MainActivity.this, MyBackgroundService.class);
                startService(startServiceIntent);

                sm = (SensorManager)getSystemService(SENSOR_SERVICE);
                a = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
                g = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
                m = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
                p = sm.getDefaultSensor(Sensor.TYPE_PRESSURE);
                r = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
                v = sm.getDefaultSensor(Sensor.TYPE_MOTION_DETECT);
                l = sm.getDefaultSensor(Sensor.TYPE_PROXIMITY);

                if(a!=null && g!=null)
                {
                    flag = true;
                    sm.registerListener(MainActivity.this, a, sm.SENSOR_DELAY_NORMAL);
                    sm.registerListener(MainActivity.this, g, sm.SENSOR_DELAY_NORMAL);
                }
                if(a == null && g == null && m == null && p == null && r == null && v == null && l == null)
                {
                    Toast.makeText(MainActivity.this,"No sensors found",Toast.LENGTH_LONG).show();
                }
                else
                {

                    sm.registerListener(MainActivity.this, a, SensorManager.SENSOR_DELAY_NORMAL);
                    sm.registerListener(MainActivity.this, g, SensorManager.SENSOR_DELAY_NORMAL);
                    sm.registerListener(MainActivity.this, m, SensorManager.SENSOR_DELAY_NORMAL);
                    sm.registerListener(MainActivity.this, p, SensorManager.SENSOR_DELAY_NORMAL);
                    sm.registerListener(MainActivity.this, r, SensorManager.SENSOR_DELAY_NORMAL);
                    sm.registerListener(MainActivity.this, v, SensorManager.SENSOR_DELAY_NORMAL);
                    sm.registerListener(MainActivity.this, l, SensorManager.SENSOR_DELAY_NORMAL);
                    flag = true;
                }
            }
        });
        b2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                tv1.setText("Background Service Stoped");

                stopService(startServiceIntent);
                flag = false;
            }
        });
    }
    @RequiresApi(api = Build.VERSION_CODES.Q)
    public void onSensorChanged(SensorEvent sensorEvent){
        if(flag == true)
        {
            if(sensorEvent.sensor.getType()==Sensor.TYPE_ACCELEROMETER){
               avals = sensorEvent.values;
            }
            if(sensorEvent.sensor.getType()==Sensor.TYPE_GYROSCOPE){
                gvals = sensorEvent.values;
            }
            if(sensorEvent.sensor.getType()==Sensor.TYPE_MAGNETIC_FIELD){
                mvals = sensorEvent.values;
            }
            if(sensorEvent.sensor.getType()==Sensor.TYPE_PRESSURE){
                pvals = sensorEvent.values;
            }
            if(sensorEvent.sensor.getType()==Sensor.TYPE_ROTATION_VECTOR){
                rvals = sensorEvent.values;
            }
            if(sensorEvent.sensor.getType()==Sensor.TYPE_MOTION_DETECT){
                vvals = sensorEvent.values;
            }
            if(sensorEvent.sensor.getType()==Sensor.TYPE_PROXIMITY){
                lvals = sensorEvent.values;

            }
            //String appInfo;
            String msg =  "time:"+ String.valueOf(sensorEvent.timestamp)+"Acc:"+Arrays.toString(avals)+
                    "Gyro:"+Arrays.toString(gvals)+"Mag:"+Arrays.toString(mvals)+"Pre:"+Arrays.toString(pvals)+
                    "rot:"+Arrays.toString(rvals)+"Mot:"+Arrays.toString(vvals)+"prox:"+Arrays.toString(lvals);
            writemsg(msg);
            Toast.makeText(MainActivity.this,"Sensor Value appended",Toast.LENGTH_LONG).show();
        }
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
    public void writemsg(String msg)
    {
        try {
            // Create a storage reference from our app
            FirebaseStorage storage = FirebaseStorage.getInstance();
            StorageReference storageRef = storage.getReference().child("Document");
            storageRef.child("file.txt").putBytes(msg.getBytes()).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Toast.makeText(MainActivity.this, "File Uploaded Sucessfully", Toast.LENGTH_SHORT).show();
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(MainActivity.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
            });

            File dir = new File(MainActivity.this.getFilesDir(), "sensordata");
            if (!dir.exists()) {
                dir.mkdir();
            }
            File f1 = new File(dir, filename);
            FileWriter fw = new FileWriter(f1, true);
            fw.append(msg + "\n");
            fw.close();
            //StorageReference storageRef = FirebaseStorage.getInstance().reference().child("folderName/file.jpg");
            Uri file = Uri.fromFile(new File("dir/filename"));
            UploadTask uploadTask = storageRef.putFile(file);
            uploadTask.addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onProgress(UploadTask.TaskSnapshot snapshot) {
                    System.out.println(snapshot.getBytesTransferred());
                }
            });
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

    }

    /*

        try {
        File f1 = new File("gs://iotmobilesenordata.appspot.com/test", filename);
        FileWriter fw = new FileWriter(f1,true);

            fw.append(msg+"\n");
            fw.close();


        UploadTask uploadTask = mountainsRef.putFile(Uri.parse("gs://iotmobilesenordata.appspot.com/test"));
        // Listen for state changes, errors, and completion of the upload.
        uploadTask.addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                double progress = (100.0 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                System.out.println("Upload is " + progress + "% done");
            }
        }).addOnPausedListener(new OnPausedListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onPaused(UploadTask.TaskSnapshot taskSnapshot) {
                System.out.println("Upload is paused");
            }
        }).addOnFailureListener(new OnFailureListener() {

            public void onFailure(@NonNull Exception exception) {
                // Handle unsuccessful uploads
            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {

            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                // Handle successful uploads on complete
                // ...

                //Deletes the file from the local system
                f1.delete();

            }
        });}
        /*try{
           File dir = new File(MainActivity.this.getFilesDir(),"sensordata");
           if(!dir.exists())
           {
               dir.mkdir();
           }
           File f1 = new File(dir, filename);
           FileWriter fw = new FileWriter(f1,true);
           fw.append(msg+"\n");
           fw.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }*/
}